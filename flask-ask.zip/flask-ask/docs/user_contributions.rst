User Contributions
==================

Have an article or video to submit? Please send it to john@johnwheeler.org

`Flask-Ask: A New Python Framework for Rapid Alexa Skills Kit Development <https://developer.amazon.com/public/community/post/Tx14R0IYYGH3SKT/Flask-Ask-A-New-Python-Framework-for-Rapid-Alexa-Skills-Kit-Development>`_

  by John Wheeler

`Running with Alexa Part I. <http://www.timkl.com/posts/running-with-alexa>`_

  by Tim Kjær Lange

`Intro and Skill Logic - Alexa Skills w/ Python and Flask-Ask Part 1 <https://pythonprogramming.net/intro-alexa-skill-flask-ask-python-tutorial/>`_

  by Harrison Kinsley

`Headlines Function - Alexa Skills w/ Python and Flask-Ask Part 2 <https://pythonprogramming.net/headlines-function-alexa-skill-flask-ask-python-tutorial/>`_

  by Harrison Kinsley

`Testing our Skill - Alexa Skills w/ Python and Flask-Ask Part 3 <https://pythonprogramming.net/testing-deploying-alexa-skill-flask-ask-python-tutorial/>`_

  by Harrison Kinsley

`Flask-Ask — A tutorial on a simple and easy way to build complex Alexa Skills <https://blog.craftworkz.co/flask-ask-a-tutorial-on-a-simple-and-easy-way-to-build-complex-alexa-skills-426a6b3ff8bc#.70eay9n07>`_

  by Bjorn Vuylsteker
